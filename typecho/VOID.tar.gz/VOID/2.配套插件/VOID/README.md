# VOID 插件

**配合 [VOID 主题](https://github.com/AlanDecode/Typecho-Theme-VOID)使用**

使用方法：下载本插件，**解压后将文件夹名称修改为 VOID**，上传至插件目录后启用。